/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var menudata={children:[
{text:"Main Page",url:"index.html"},
{text:"Classes",url:"annotated.html",children:[
{text:"Class List",url:"annotated.html"},
{text:"Class Index",url:"classes.html"},
{text:"Class Members",url:"functions.html",children:[
{text:"All",url:"functions.html",children:[
{text:"b",url:"functions.html#index_b"},
{text:"c",url:"functions.html#index_c"},
{text:"d",url:"functions.html#index_d"},
{text:"f",url:"functions.html#index_f"},
{text:"g",url:"functions.html#index_g"},
{text:"i",url:"functions.html#index_i"},
{text:"m",url:"functions.html#index_m"},
{text:"o",url:"functions.html#index_o"},
{text:"p",url:"functions.html#index_p"},
{text:"s",url:"functions.html#index_s"},
{text:"t",url:"functions.html#index_t"},
{text:"u",url:"functions.html#index_u"},
{text:"w",url:"functions.html#index_w"},
{text:"~",url:"functions.html#index__7E"}]},
{text:"Functions",url:"functions_func.html",children:[
{text:"b",url:"functions_func.html#index_b"},
{text:"c",url:"functions_func.html#index_c"},
{text:"g",url:"functions_func.html#index_g"},
{text:"m",url:"functions_func.html#index_m"},
{text:"s",url:"functions_func.html#index_s"},
{text:"t",url:"functions_func.html#index_t"},
{text:"u",url:"functions_func.html#index_u"},
{text:"w",url:"functions_func.html#index_w"},
{text:"~",url:"functions_func.html#index__7E"}]},
{text:"Typedefs",url:"functions_type.html"},
{text:"Enumerations",url:"functions_enum.html"},
{text:"Enumerator",url:"functions_eval.html"}]}]},
{text:"Files",url:"files.html",children:[
{text:"File List",url:"files.html"},
{text:"File Members",url:"globals.html",children:[
{text:"All",url:"globals.html",children:[
{text:"_",url:"globals.html#index__5F"},
{text:"a",url:"globals.html#index_a"},
{text:"c",url:"globals.html#index_c"},
{text:"f",url:"globals.html#index_f"},
{text:"h",url:"globals.html#index_h"},
{text:"l",url:"globals.html#index_l"},
{text:"m",url:"globals.html#index_m"},
{text:"o",url:"globals.html#index_o"},
{text:"p",url:"globals.html#index_p"},
{text:"r",url:"globals.html#index_r"},
{text:"s",url:"globals.html#index_s"},
{text:"u",url:"globals.html#index_u"}]},
{text:"Variables",url:"globals_vars.html"},
{text:"Macros",url:"globals_defs.html",children:[
{text:"a",url:"globals_defs.html#index_a"},
{text:"c",url:"globals_defs.html#index_c"},
{text:"f",url:"globals_defs.html#index_f"},
{text:"h",url:"globals_defs.html#index_h"},
{text:"l",url:"globals_defs.html#index_l"},
{text:"m",url:"globals_defs.html#index_m"},
{text:"o",url:"globals_defs.html#index_o"},
{text:"p",url:"globals_defs.html#index_p"},
{text:"r",url:"globals_defs.html#index_r"},
{text:"s",url:"globals_defs.html#index_s"},
{text:"u",url:"globals_defs.html#index_u"}]}]}]}]}
